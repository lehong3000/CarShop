<?php /* Smarty version Smarty-3.1.19, created on 2017-11-08 06:31:18
         compiled from "D:\xampp\htdocs\auto_store\dong-goi\auto-store_home1_qs\themes\classic\templates\catalog\_partials\products-bottom.tpl" */ ?>
<?php /*%%SmartyHeaderCode:317915a0296a66d6937-75546865%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6f5f59d9170304040a3ecb077d899a8543cd8b8d' => 
    array (
      0 => 'D:\\xampp\\htdocs\\auto_store\\dong-goi\\auto-store_home1_qs\\themes\\classic\\templates\\catalog\\_partials\\products-bottom.tpl',
      1 => 1503903076,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '317915a0296a66d6937-75546865',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_5a0296a66d87f5_89628824',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a0296a66d87f5_89628824')) {function content_5a0296a66d87f5_89628824($_smarty_tpl) {?>
<div id="js-product-list-bottom"></div>
<?php }} ?>
